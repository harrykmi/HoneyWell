﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duplicates
{
    class Program
    {
        static void Main(string[] args)
        {
            RemoveDuplicates();
        }

        private static void RemoveDuplicates()
        {
            try
            {
                while (true)
                {
                    Console.WriteLine("Enter the Sentence:");
                    string sentence = Console.ReadLine();
                    string resultSentence ="";
                    string[] words = sentence.ToLower().Split(' ');
                    int count;

                    for (int i = 0; i < words.Length; i++)
                    {
                        if (i == 0) {
                            resultSentence = sentence;
                        }
                        
                        count = 1;
                        for (int j = i + 1; j < words.Length; j++)
                        {
                            if (words[i].Equals(words[j]))
                            {
                                count++;
                                words[j] = "0";
                            }
                        }

                        if (count > 1 && words[i] != "0")
                        {
                            //Console.WriteLine(words[i]);
                            resultSentence = removeWord(resultSentence, words[i]);
                        }
                    }
                    Console.WriteLine("Output");
                    Console.WriteLine(resultSentence);
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        public static String removeWord(String str, String word)
        {

            if (str.Contains(word))
            {

                String tempWord = word + " ";
                str = str.Replace(tempWord, "");

                tempWord = " " + word;
                str = str.Replace(tempWord, "");
            }

            return str;
        }
    }
}
