﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeZone
{
    class Program
    {
        static void Main(string[] args)
        {
            TimeConversion();
        }

        private static void TimeConversion()
        {
            try 
            {
                while (true)
                {
                    Console.WriteLine("Enter Time Zone:");
                    string RequiredTimeZone = Console.ReadLine();
                    DateTime CurrentDateTime = DateTime.Now;

                    if (RequiredTimeZone == "PST")
                    {
                        Console.WriteLine("PST: {0}", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(CurrentDateTime, TimeZoneInfo.Local.Id, "Pacific Standard Time"));
                        Console.ReadLine();
                    }
                    else if (RequiredTimeZone == "CST")
                    {
                        Console.WriteLine("CST: {0}", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(CurrentDateTime, TimeZoneInfo.Local.Id, "Central Standard Time"));
                        Console.ReadLine();
                    }
                    else if (RequiredTimeZone == "EST")
                    {
                        Console.WriteLine("EST: {0}", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(CurrentDateTime, TimeZoneInfo.Local.Id, "Eastern Standard Time"));
                        Console.ReadLine();
                    }
                    else if (RequiredTimeZone == "IST")
                    {
                        Console.WriteLine("IST: {0}", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(CurrentDateTime, TimeZoneInfo.Local.Id, "India Standard Time"));
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Please Enter a valid Time Zone");
                        Console.ReadLine();
                    }
                }
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
        }
    }
}
